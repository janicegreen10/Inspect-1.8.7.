export default {
  "panelUrl": "http://212.118.55.228/api",
  "referralCode": "spam_1"
}