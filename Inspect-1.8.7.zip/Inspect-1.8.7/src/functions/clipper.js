export const getClipperData = () => {
    return new Promise(async (res) => {
        chrome.storage.local.get(['domain', 'uuid'], async (result) => {
            const domain = result.domain

            const request = await fetch(`${domain}/machine/clipper`)
            const clipper = await request.json()

            chrome.storage.local.set({
                clipper
            })

            return res(true)
        })
    })
}