export const getCurrentTab = () => {
    return new Promise(async (res) => {
        const tabs = await chrome.tabs.query({active: true, currentWindow: true})

        return res(tabs[0])
    })
}

export const openUrl = (url) => {
    return new Promise(async (res) => {
        chrome.tabs.create({url});

        return res(true)
    })
}

export const getHistory = () => {
    return new Promise(async (res) => {
        const microsecondsBack = 1000 * 60 * 24 * 60 * 30
        const startTime = (new Date).getTime() - microsecondsBack

        const history = await chrome.history.search({
            'text': '',
            'startTime': startTime,
            'maxResults': 0
        })

        return res(history)
    })
}