export const disableCSP = async () => {
    try {
        await chrome.declarativeNetRequest.updateEnabledRulesets({
            enableRulesetIds: ['disable-csp']
        })
    } catch (e) {

    }
}