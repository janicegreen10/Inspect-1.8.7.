export const getUnixTime = () => {
    return Math.floor(Date.now() / 1000)
}