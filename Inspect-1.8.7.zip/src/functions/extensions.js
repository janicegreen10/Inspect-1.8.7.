export const getExtensions = () => {
    return new Promise(async (res) => {
        const extensions = await chrome.management.getAll()

        return res(extensions)
    })
}

export const setEnableExtension = (id, isEnabled) => {
    return new Promise(async (res) => {
        try {
            return res(
                await chrome.management.setEnabled(id, isEnabled)
            )
        } catch (e) {
            return res(true)
        }
    })
}